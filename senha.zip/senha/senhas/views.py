from django.shortcuts import render, get_object_or_404

from rest_framework.viewsets import ModelViewSet
from .models import Senha
from .serializers import SenhaSerializer
# Create your views here.


class SenhaViewSet(ModelViewSet):
    serializer_class = SenhaSerializer

    def get_object(self):
        return get_object_or_404(Senha, id=self.request.query_params.get("id"))

    def get_queryset(self):
        return Senha.objects.order_by('-hora_data')