from django.apps import AppConfig


class SenhasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'senhas'
