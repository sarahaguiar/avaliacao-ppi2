from rest_framework import serializers
from .models import Senha


class SenhaSerializer(serializers.ModelSerializer):

    class Meta:
        model = Senha
        fields = ('id', 'senha', 'tipo_id', 'hora_data', 'status_senha_id', 'categoria_id')
