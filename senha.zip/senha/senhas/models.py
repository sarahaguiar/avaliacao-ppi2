from django.db import models

class Tipo(models.Model):

    nome = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return self.nome

class StatusSenha(models.Model):

    nome = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return self.nome

class Categoria(models.Model):

    nome = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return self.nome

class Senha(models.Model):

    senha = models.IntegerField()
    hora_data = models.DateTimeField(auto_now=True)
    tipo_id = models.ForeignKey(Tipo, on_delete=models.CASCADE)
    status_senha_id = models.ForeignKey(StatusSenha, on_delete=models.CASCADE)
    categoria_id = models.ForeignKey(Categoria, on_delete=models.CASCADE)

    def __str__(self):
        return self.senha
